'use strict'

var demoApp = angular.module('demo', [ 'ui.bootstrap', 'demo.controllers',
		'demo.services' ]);
demoApp.constant("CONSTANTS", {
	getEmployeeByIdUrl : "/employee/getEmployee/",
	getAllEmployees : "/employee/getAllEmployees",
	saveEmployee : "/employee/saveEmployee"
});