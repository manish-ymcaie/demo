'use strict'

var module = angular.module('demo.controllers', []);
module.controller("EmployeeController", [ "$scope", "EmployeeService",
		function($scope, EmployeeService) {

	$scope.orderByField = 'employeeId';
	  $scope.reverseSort = false;
	
			$scope.employeeDto = {
				employeeId : null,
				employeeName : null,
				salary : null,
				hiredate : null,
				skillDtos : []
			};
			$scope.skills = [];
			
			EmployeeService.getEmployeeById(1).then(function(value) {
				console.log(value.data);
			}, function(reason) {
				console.log("error occured");
			}, function(value) {
				console.log("no callback");
			});

			$scope.saveEmployee = function() {
				$scope.employeeDto.skillDtos = $scope.skills.map(skill => {
					return {skillId: null, skillName: skill};
				});
				EmployeeService.saveEmployee($scope.employeeDto).then(function() {
					console.log("works");
					EmployeeService.getAllEmployees().then(function(value) {
						$scope.allEmployees= value.data;
					}, function(reason) {
						console.log("error occured");
					}, function(value) {
						console.log("no callback");
					});

					$scope.skills = [];
					$scope.employeeDto = {
						employeeId : null,
						employeeName : null,
						salary : null,
						hiredate : null,
						skillDtos : []
					};
				}, function(reason) {
					console.log("error occured");
				}, function(value) {
					console.log("no callback");
				});
			}
			
			
			$scope.listEmployee = function() {
				/*$scope.employeeDto.skillDtos = $scope.skills.map(skill => {
					return {skillId: null, skillName: skill};
				});*/
					EmployeeService.getAllEmployees().then(function(value) {
						$scope.allEmployees= value.data;
					}, function(reason) {
						console.log("error occured");
					}, function(value) {
						console.log("no callback");
					});

					$scope.skills = [];
					$scope.employeeDto = {
						employeeId : null,
						employeeName : null,
						salary : null,
						hiredate : null,
						skillDtos : []
					};
				
			}
		} ]);