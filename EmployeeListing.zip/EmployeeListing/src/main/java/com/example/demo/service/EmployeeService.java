package com.example.demo.service;

import java.util.List;

import com.example.demo.dto.EmployeeDto;

public interface EmployeeService {
    EmployeeDto getEmployeeById(Integer employeeId);
    void saveEmployee(EmployeeDto employeeDto);
    List<EmployeeDto> getAllEmployees();
}
