package com.example.demo.service.impl;

import com.example.demo.converter.EmployeeConverter;
import com.example.demo.dto.EmployeeDto;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.service.EmployeeService;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeServiceimpl implements EmployeeService {
	@Autowired
	EmployeeRepository employeeRepository;

	@Override
	public EmployeeDto getEmployeeById(Integer employeeId) {
		return EmployeeConverter.entityToDto(employeeRepository.getOne(employeeId));
	}

	@Override
	public void saveEmployee(EmployeeDto employeeDto) {
		employeeRepository.save(EmployeeConverter.dtoToEntity(employeeDto));
	}

	@Override
	public List<EmployeeDto> getAllEmployees() {
		return employeeRepository.findAll().stream().map(EmployeeConverter::entityToDto).collect(Collectors.toList());
	}
}
