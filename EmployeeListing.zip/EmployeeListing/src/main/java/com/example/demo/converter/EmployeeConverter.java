package com.example.demo.converter;

import java.util.stream.Collectors;

import com.example.demo.dto.EmployeeDto;
import com.example.demo.entity.Employee;

public class EmployeeConverter {
	public static Employee dtoToEntity(EmployeeDto employeeDto) {
		Employee employee = new Employee(employeeDto.getEmployeeName(), null, employeeDto.getSalary(), employeeDto.getHiredate());
		employee.setEmployeeId(employeeDto.getEmployeeId());
		employee.setSalary(employeeDto.getSalary());
		employee.setHiredate(employeeDto.getHiredate());
		employee.setSkills(employeeDto.getSkillDtos().stream().map(SkillConverter::dtoToEntity).collect(Collectors.toList()));
		return employee;
	}

	public static EmployeeDto entityToDto(Employee employee) {
		EmployeeDto employeeDto = new EmployeeDto(employee.getEmployeeId(), employee.getEmployeeName(), null, employee.getSalary(), employee.getHiredate());
		employeeDto.setSkillDtos(employee.getSkills().stream().map(SkillConverter::entityToDto).collect(Collectors.toList()));
		employeeDto.setSalary(employee.getSalary());
		employeeDto.setHiredate(employee.getHiredate());
		return employeeDto;
	}
}
