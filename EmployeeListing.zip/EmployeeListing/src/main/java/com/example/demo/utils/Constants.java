package com.example.demo.utils;

public interface Constants {
	static final String GET_EMP_BY_ID = "/getEmployee/{employeeId}";
	static final String GET_ALL_EMPLOYEES= "/getAllEmployees";
	static final String SAVE_EMPLOYEE = "/saveEmployee";
}
