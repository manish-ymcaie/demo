package com.example.demo.dto;

import java.util.ArrayList;
import java.util.List;

public class EmployeeDto {
    Integer employeeId;
    String employeeName;
	Integer salary;
    String hiredate;
    
    List<SkillDto> skillDtos= new ArrayList<>();

    public EmployeeDto(Integer employeeId, String employeeName, List<SkillDto> skillDtos, Integer salary, String hiredate) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.skillDtos = skillDtos;
        this.salary = salary;
        this.hiredate= hiredate;
    }

    public EmployeeDto() {
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public List<SkillDto> getSkillDtos() {
        return skillDtos;
    }

    public void setSkillDtos(List<SkillDto> skillDtos) {
        this.skillDtos = skillDtos;
    }
    
    public Integer getSalary() {
		return salary;
	}

	public void setSalary(Integer salary) {
		this.salary = salary;
	}

	public String getHiredate() {
		return hiredate;
	}

	public void setHiredate(String hiredate) {
		this.hiredate = hiredate;
	}
}
